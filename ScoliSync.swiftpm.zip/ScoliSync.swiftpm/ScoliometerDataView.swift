//
//  ScoliometerDataView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/3.
//

import SwiftUI
import SwiftData

struct ScoliometerDataView: View {
    @Query private var scoliometerDatasets: [ScoliometerData]
    @Environment(\.modelContext) private var modelContext
    
    var body: some View {
        VStack {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(scoliometerDatasets) { dataset in
                        ScoliometerDatasetGridView(dataset: dataset)
                        .padding()
                        .contextMenu {
                            Button(role: .destructive) {
                                deleteData(dataset)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                    
                    NavigationLink(destination: ScoliometerMeasureView()) {
                        VStack {
                            Text("Add Measurement")
                                .foregroundColor(.secondary)
                                .bold()
                                .padding()
                            
                            Image(systemName: "plus.circle")
                                .foregroundColor(.secondary)
                                .font(.title)
                            
                        }
                        .frame(width: 250.0, height: 250.0)
                        .background(
                            RoundedRectangle(cornerRadius: 16) // 圓角矩形背景
                                .fill(.ultraThinMaterial) // 可以選擇背景顏色
                                // .shadow(color: .secondary, radius: 5) // 可選擇陰影效果
                        )
                        .padding()
                    }
                }
                .animation(.default, value: scoliometerDatasets.count)
            }
        }
        // .navigationTitle("Scoliometer Dataset")
    }
    
    private func deleteData(_ dataset: ScoliometerData) {
        modelContext.delete(dataset)
        try? modelContext.save()
    }
}

struct ScoliometerDatasetGridView: View {
    let dataset: ScoliometerData
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    
    @State private var rotationAngle: Double = 0
    
    
    var body: some View {
        VStack {
            VStack {
                Text("\(abs(dataset.angle), specifier: "%.2f")°")
                    .font(.title)
                    .foregroundColor(.primary)
                    .padding(50)
                    .background(Circle().stroke(lineWidth: 4).foregroundColor(.secondary))
                    .rotationEffect(.degrees(rotationAngle))
                    .animation(.easeInOut, value: rotationAngle)
                
                Text(dataset.time.formatted(.dateTime.year().month().day()))
                    .font(.body)
                    .bold()
                    .foregroundColor(.secondary)
                    .frame(height: 20.0)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
            }
            .padding()
        }
        .frame(width: 250.0, height: 250.0)
        .background(
            RoundedRectangle(cornerRadius: 16) // 圓角矩形背景
                .fill(.ultraThinMaterial) // 可以選擇背景顏色
                .shadow(color: Color.black.opacity(0.2), radius: 5) // 可選擇陰影效果
        )
        .onTapGesture {
            impactFeedback.impactOccurred()
            
            if rotationAngle == 0 {
                rotationAngle = dataset.angle
            }
            else {
                rotationAngle = 0
            }
        }

    }
}
