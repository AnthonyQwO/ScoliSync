//
//  ScoliometerInfoView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/4.
//

import SwiftUI

struct ScoliometerInfoView: View {
    @State private var angleLock = false
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 12) {
                TitleTypewriterView(
                    text: "📏 What is a Scoliometer?",
                    typingSpeed: 0.08,
                    typeFeedback: false
                )
                .font(.title)
                .bold()
                
                ScrollView {
                    Text("A **Scoliometer** is an instrument used to measure the **degree of scoliosis**, a condition involving abnormal curvature of the spine. 🏥 It is commonly used in clinical examinations to assess whether a patient may require further diagnostic tests, such as X-rays, or treatment.")
                    
                    Divider()
                    
                    HStack {
                        Text("🔹How a Scoliometer Works")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    
                    Image("placeScoliometerOnBack 1")
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    Text("The primary function of a **Scoliometer** is to measure the **Angle of Trunk Rotation (ATR)**. The measurement process typically follows these steps:\n")
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. **Adam’s Forward Bend Test** – The patient bends forward, allowing the examiner to observe any **asymmetrical protrusions** in the spine.")
                        Text("2. **Placing the Scoliometer** – The instrument is placed on the patient’s back, sliding along the **spinal midline** to identify the most pronounced point of curvature.")
                        Text("3. **Reading the Measurement** – Observe the angle displayed on the Scoliometer.")
                        
                        HStack {
                            Spacer()
                            
                            VStack {
                                Button("0°") {
                                    angleLock.toggle()
                                    impactFeedback.impactOccurred()
                                }
                                .font(.title)
                                .foregroundColor(.primary)
                                
                                .padding(50) // 增加內邊距，讓圓形有足夠空間
                                .background(Circle().stroke(lineWidth: 4).foregroundColor(.secondary).opacity(angleLock ? 1 : 0.3)) // 外框圓形
                                .animation(.easeInOut, value: angleLock) // 淡入動畫
                                
                                if angleLock {
                                    Button("Save") {
                                    }
                                    .foregroundStyle(.secondary)
                                    .font(.title)
                                    // .bold()
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(.secondary, lineWidth: 3)
                                    )
                                    .opacity(angleLock ? 1 : 0)
                                    .animation(.easeInOut, value: angleLock) // 淡入動畫
                                    .padding()
                                }
                                
                                Text("Press the circle to save.")
                                    .font(.caption)
                            }
                            
                            Spacer()
                        }
                        
                        
                        Text("If the **ATR exceeds 5–7 degrees**, further evaluation may be necessary.")
                    }
                    
                    Divider()
                    
                    HStack {
                        Text("⚠️ Important Note")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.red)
                        
                        Spacer()
                    }
                    
                    Text("While a **Scoliometer** is a useful tool, it **cannot diagnose scoliosis on its own**. If there are concerns, a professional medical evaluation is recommended for a more accurate assessment. 🩺")
                        .foregroundColor(.red)
                }
                .foregroundColor(.secondary)
                .padding(.horizontal)
                
                NavigationLink(destination: ScoliometerMeasureView()) {
                    HStack {
                        Spacer()
                        
                        Text("Try Now !")
                            .bold()
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(height: 40.0)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                        
                        Spacer()
                    }
                }

            }
            .animation(.easeInOut, value: angleLock)
        }
        .padding(.horizontal)
    }
    
}


#Preview {
    ScoliometerInfoView()
}
