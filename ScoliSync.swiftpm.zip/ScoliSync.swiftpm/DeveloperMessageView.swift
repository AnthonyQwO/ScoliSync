//
//  DeveloperMessageView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/5.
//

import SwiftUI

struct DeveloperMessageView: View {
    private var images: [String] = ["042721", "072221", "080822", "082824", "120924"]
    var body: some View {
        VStack(alignment: .leading) {
            Text("Developer's Message")
                .font(.title2)
                .bold()
                .foregroundStyle(.primary)
            
            ScrollView {
                VStack(alignment: .leading) {
                    Text("I am a severe scoliosis patient. \nI was diagnosed with scoliosis in 2020, and in 2024, my condition worsened, leading me to undergo surgery. \n\nIf you also have scoliosis, I strongly encourage you to seek professional medical treatment as soon as possible. \nDepending on your condition, you may need to wear a brace and engage in exercises. \nAlthough the correction process can be uncomfortable, please stay strong and persevere. \n\nIf you are a severe scoliosis patient, it is even more crucial to get a professional diagnosis and receive appropriate treatment as soon as possible.\n")
                    
                    Text("All the X-ray images used in this app are from my own spine X-rays taken at different stages.")
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(images, id: \.self) { image in
                                Image(image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 150)
                            }
                        }
                    }
                    
                    Text("If you have scoliosis, remember to monitor your condition regularly to avoid missing the best treatment window. This is the core reason behind the development of this app.\n")
                    
                    Text("Anthony Tang")
                    
                }
            }
        }
        .foregroundColor(.secondary)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
    }
}

#Preview {
    DeveloperMessageView()
}
