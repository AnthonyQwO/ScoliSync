//
//  MainPageView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/1/30.
//

import SwiftUI
import SwiftData

struct MainPageView: View {
    @Query private var radiologyDatasets: [RadiologyData]
    @Query private var scoliometerDatasets: [ScoliometerData]
    
    @State private var showIntroductionPage: Bool = false
    @State private var isActive: Bool = false
    @State private var selectedSection: Int = 0
    @State private var lastIndex: Int = 0
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
    
    let exploreSection: [(title: String, icon: String, imageName: String, color: Color, destination: AnyView)] = [
        (title: "Scoliosis",
         icon: "point.topleft.down.to.point.bottomright.curvepath.fill",
         imageName: "080822",
         color: .accentColor,
         destination: AnyView(ScoliosisInfoView())),
        
        (title: "Cobb Angle",
         icon: "angle",
         imageName: "CobbExample",
         color: .blue,
         destination: AnyView(CobbAngleInfoView())),
        
        (title: "Scoliometer",
         icon: "level",
         imageName: "placeScoliometerOnBack 1",
         color: .green,
         destination: AnyView(ScoliometerInfoView())),
        
        (title: "Brace",
         icon: "figure.arms.open",
         imageName: "scoliosisBrace",
         color: .yellow,
         destination: AnyView(ScoliosisBraceInfoView()))
    ]
        
    var body: some View {
        NavigationView {
            ZStack {
                ScrollView {
                    VStack {
                        HStack {
                            NavigationLink(destination: ExploreView(exploreSection: exploreSection)) {
                                HStack {
                                    Text("Explore")
                                        
                                    Label("", systemImage: "chevron.right")
                                }
                                .font(.title2)
                                .bold()
                                .foregroundColor(.primary)
                            }
                        
                            Spacer()
                        }
                        .padding()
                        
                        NavigationLink(
                            destination: exploreSection[lastIndex].destination,
                            isActive: $isActive
                        ) {
                            // 內容視圖
                            Button(action: {
                                lastIndex = selectedSection
                                
                                // 生成隨機索引
                                var newIndex: Int
                                repeat {
                                    newIndex = Int.random(in: 0..<exploreSection.count)
                                } while newIndex == selectedSection
                                
                                // 更新索引並觸發導航
                                selectedSection = newIndex
                                
                                isActive = true
                                
                                impactFeedback.impactOccurred()
                                
                            }) {
                                let item = exploreSection[selectedSection]
                                
                                ZStack {
                                    // 背景層
                                    item.color
                                    
                                    // 模糊效果層
                                    Rectangle()
                                        .fill(.ultraThinMaterial)
                                    
                                    // 漸層層
                                    LinearGradient(
                                        gradient: Gradient(colors: [.clear, item.color.opacity(0.8)]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                    
                                    // 右側圖片
                                    GeometryReader { geometry in
                                        Image(item.imageName)
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: geometry.size.width / 2)
                                            .clipped()
                                            .position(x: geometry.size.width * 0.75, y: geometry.size.height / 2)
                                    }
                                    
                                    // 內容層
                                    HStack {
                                        VStack(alignment: .leading, spacing: 30) {
                                            Image(systemName: item.icon)
                                                .foregroundColor(.white)
                                                .font(.title)
                                                .bold()
                                            
                                            Text(item.title)
                                                .foregroundColor(.white)
                                                .font(.title3)
                                        }
                                        .padding()
                                        Spacer()
                                    }
                                }
                                .frame(width: 300, height: 180)
                                .clipShape(RoundedRectangle(cornerRadius: 25))
                                // .shadow(color: .secondary, radius: 5)
                                .padding(.horizontal)
                            }
                        }
                        .animation(.default, value: selectedSection)
                    }
                    
                    VStack {
                        
                        NavigationLink(destination: CobbAngleMeasureView()) {
                            
                            VStack {
                                HStack {
                                    HStack {
                                        Text("Playground")
                                        
                                        Label("", systemImage: "chevron.right")
                                    }
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.primary)
                                    Spacer()
                                }
                                .padding(.horizontal)
                                
                                VStack(alignment: .leading, spacing: 30) {
                                    Image(systemName: "ruler")
                                    Text("How To Measure Cobb Angle ?")
                                }
                                .padding()
                                .frame(width: 300, height: 180, alignment: .leading)
                                .background(.ultraThinMaterial)
                                .background(.purple)
                                .cornerRadius(25)
                                .foregroundColor(.white)
                            }
                            
                        }
                        
                    }
                    .padding(.vertical)

                    VStack {
                        HStack {
                            NavigationLink(destination: RadiologyHistoryView()) {
                                HStack {
                                    Text("Spine X-Ray")
                                        
                                    Label("", systemImage: "chevron.right")
                                }
                                .font(.title2)
                                .bold()
                                .foregroundColor(.primary)
                            }
                        
                            Spacer()
                        }
                        .padding()
                        
                        RadiologyDataView()
                    }
                    
                    VStack {
                        HStack {
                            NavigationLink(destination: ScoliometerHistoryView()) {
                                HStack {
                                    Text("Scoliometer")
                                        
                                    Label("", systemImage: "chevron.right")
                                }
                                .font(.title2)
                                .bold()
                                .foregroundColor(.primary)
                            }
                            Spacer()
                        }
                        .padding()
                        
                        ScoliometerDataView()
                    }
                    
                    Text("This app is for informational purposes only and does not provide any medical diagnosis or treatment. \nThe developer is not a medical professional, and the accuracy of the information cannot be guaranteed. \nPlease consult a healthcare professional for medical advice.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding()
                    
                    
                }
                .navigationTitle("ScoliSync")
                
                FloatingButton()
                
                Spacer()
            }
        }
        .onAppear {
            showIntroductionPage = true
            selectedSection = Int.random(in: 0..<exploreSection.count)
        }
        .fullScreenCover(isPresented: $showIntroductionPage) {
            IntroductionView()
        }

    }
}
