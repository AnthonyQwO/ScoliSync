//
//  IntroductionView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/4.
//

import SwiftUI

struct IntroductionView: View {
    @Environment(\.dismiss) private var dismiss
    
    @State private var showText: Int = 0
    
    var body: some View {
        VStack {
            TitleTypewriterView(
                text: "Welcome to ScoliSync!",
                typingSpeed: 0.08,
                typeFeedback: true
            )
            .font(.title)
            .bold()
            
            if showText == 1 {
                WhatIsScoliSyncView()
            }
            else if showText == 2 {
                DeveloperMessageView()
            }
            else if showText == 3 {
                Text("This app is for informational purposes only and does not provide any medical diagnosis or treatment. \n\nThe developer is not a medical professional, and the accuracy of the information cannot be guaranteed. \n\nPlease consult a healthcare professional for medical advice.")
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .bold()
                    .padding()
            }
            
            Button(action: {
                showText += 1
            }) {
                HStack {
                    Text("Continue")
                        .bold()
                    
                    // Image(systemName: "chevron.right")
                }
                .font(.title2)
                .foregroundColor(.secondary)
                .frame(height: 40.0)
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
            }
            
        }
        .padding()
        .animation(.easeInOut(duration: 1), value: showText)
        .onChange(of: showText) {
            if showText >= 4 {
                dismiss()
            }
        }
        
    }
}

struct WhatIsScoliSyncView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("What is ScoliSync ?")
                .font(.title2)
                .bold()
                .foregroundColor(.primary)
            
            ScrollView {
                VStack(alignment: .leading) { // Add VStack inside ScrollView for left alignment
                    Text("Scoliosis refers to a condition where the spine experiences a lateral curvature. 🧑‍⚕️💡\n")
                    
                    Text("The incidence rate is about 3%, and it typically occurs in adolescents between the ages of 10 and 20. This condition worsens rapidly during the growth phase, and if it progresses to severe scoliosis, surgical treatment may be required. ⚠️📊\n")
                    
                    Text("Therefore, individuals with scoliosis need to receive immediate professional medical treatment and regular follow-ups according to the doctor's instructions. 🏥🔄\n")
                    
                    Text("ScoliSync is a tool designed to help scoliosis patients record their physical condition on their mobile phones, making it easier for them to track their progress. 📱📈 Non-scoliosis patients can also use ScoliSync to learn more about scoliosis-related knowledge. 📚🌱")
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .foregroundStyle(.secondary)
    }
}

#Preview {
    IntroductionView()
}
