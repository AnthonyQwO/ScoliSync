//
//  RadiologyDataEditView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/3.
//

import SwiftUI
import PhotosUI

struct RadiologyDataEditView: View {
    let dataset: RadiologyData  // 新增這個屬性來接收要編輯的資料集
    
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImage: UIImage?
    @State private var showPhotoZoomPage: Bool = false
    @State private var selectedDate: Date
    @State private var angle: Double?
    @State private var showAlert: Bool = false
    @State private var isEditing: Bool = false
    
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    
    // 初始化方法，用於設置初始值
    init(dataset: RadiologyData) {
        self.dataset = dataset
        _selectedDate = State(initialValue: dataset.time)
        _selectedImage = State(initialValue: dataset.image)
        _angle = State(initialValue: dataset.CobbAngle)
    }
    
    var body: some View {
        VStack {
            HStack {
                DatePicker("Select Time", selection: $selectedDate, displayedComponents: .date)
                    .labelsHidden()
                    .padding()
                
                Spacer()
                
                VStack {
                    if isEditing {
                        TextField("No Data", value: $angle, format: .number.precision(.fractionLength(2)))
                            .keyboardType(.decimalPad)
                            .onChange(of: angle) { newValue in
                                if newValue != nil {
                                    // 確保值為有效的浮點數，並保留兩位小數
                                    angle = round(newValue! * 100) / 100
                                } else {
                                    // 當無效時可以設定為 nil 或其他預設值
                                    angle = nil
                                }
                            }
                            .font(.body)
                            .bold()
                            .foregroundColor(.secondary)
                            .frame(height: 20.0)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(.ultraThinMaterial)
                            .clipShape(Capsule())
                            .onTapGesture {
                                // 觸發編輯
                                isEditing = true
                            }
                            .onSubmit {
                                // 編輯結束，切換回顯示模式
                                isEditing = false
                            }
                    } else {
                        Text(angle == nil ? "No Data" : "\(angle ?? 0, specifier: "%.2f")°")
                            .font(.body)
                            .bold()
                            .foregroundColor(.secondary)
                            .frame(height: 20.0)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(.ultraThinMaterial)
                            .clipShape(Capsule())
                            .onTapGesture {
                                // 觸發編輯
                                isEditing = true
                            }
                    }
                }

                Button(action: {
                    // 更新現有的 dataset，而不是創建新的
                    dataset.time = selectedDate
                    dataset.CobbAngle = angle
                    dataset.image = selectedImage
                    
                    do {
                        try context.save()
                        showAlert = true
                        dismiss()
                    } catch {
                        print("Failed to save context: \(error)")
                    }
                }) {
                    Image(systemName: "square.and.arrow.down")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(width: 20.0, height: 20.0)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
                .alert("Successfully saved!", isPresented: $showAlert) {}
            }
            
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .frame(maxHeight: 450)
                    .padding()
                    .onTapGesture {
                        showPhotoZoomPage = true
                    }
                
                PhotosPicker(
                    selection: $selectedItem,
                    matching: .images,
                    photoLibrary: .shared()
                ) {
                    Text("Select photo")
                        .padding(10)
                        .background(.regularMaterial)
                        .background(.blue)
                        .foregroundColor(.secondary)
                        .cornerRadius(10)
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self),
                           let uiImage = UIImage(data: data) {
                            selectedImage = uiImage
                        }
                    }
                    showPhotoZoomPage = true
                    angle = nil
                }
            }
            else {
                PhotosPicker(
                    selection: $selectedItem,
                    matching: .images,
                    photoLibrary: .shared()
                ) {
                    Text("Photo not selected yet")
                        .foregroundColor(.gray)
                        .frame(width: 300.0, height: 450.0)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 20)
                            .stroke(.secondary, lineWidth: 5))
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self),
                           let uiImage = UIImage(data: data) {
                            selectedImage = uiImage
                        }
                    }
                    showPhotoZoomPage = true
                }
            }
            
            Spacer()
        }
        .fullScreenCover(isPresented: $showPhotoZoomPage) {
            ZoomingDraggingRotatingImageView(angle: $angle, showPage: $showPhotoZoomPage, selectedImage: $selectedImage)
        }
        .padding()
        .onTapGesture {
            // 點擊空白區域時，隱藏鍵盤並停止編輯
            isEditing = false
        }
    }
}
