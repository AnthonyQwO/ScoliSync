//
//  ScoliosisBraceInfoView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/4.
//

import SwiftUI

struct ScoliosisBraceInfoView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Title Section
            TitleTypewriterView(
                text: "Scoliosis Brace 🦴",
                typingSpeed: 0.08,
                typeFeedback: false
            )
            .font(.title)
            .bold()
            .padding(.horizontal)
            
            // Scrollable Content
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    
                    HStack {
                        Spacer()
                        
                        Image("scoliosisBrace")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 200)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                        
                        Spacer()
                    }
                    
                    // Introduction
                    Text("A **scoliosis brace** is a medical device used to prevent the progression of spinal curvature in growing children and adolescents. It provides support and helps in maintaining proper spinal alignment. 🏥")
                        .padding()
                    
                    Divider()
                    
                    // Types of Scoliosis Braces
                    HStack {
                        Text("Types of Scoliosis Braces 🏗️")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("• **Boston Brace**: One of the most commonly used braces, designed to fit under the arms and around the torso. 🌆")
                        Text("• **Milwaukee Brace**: Includes a neck ring for added support, used for higher spinal curves. 🏙️")
                        Text("• **Charleston Bending Brace**: Worn at night, designed to overcorrect the curve. 🌙")
                        Text("• **Providence Brace**: Similar to the Charleston brace but custom-made to apply pressure at precise points. 🎯")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Who Needs a Brace?
                    HStack {
                        Text("Who Needs a Brace? 🤔")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("• Children and adolescents with a spinal curve between **20° and 40°**. 📏")
                        Text("• Patients who are still growing, as bracing is most effective during growth spurts. 📈")
                        Text("• Those with mild to moderate scoliosis to prevent further progression. 🛑")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Wearing and Maintenance Tips
                    HStack {
                        Text("Wearing & Maintenance Tips 🛠️")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("• Wear the brace for the recommended **18-23 hours per day**. ⏳")
                        Text("• Use a soft, seamless undershirt to prevent skin irritation. 👕")
                        Text("• Follow regular check-ups to ensure proper fit and effectiveness. 🩺")
                        Text("• Keep the brace clean and dry; wipe it regularly with mild soap and water. 🚿")
                        Text("• Stay active! Engage in doctor-approved exercises to maintain flexibility. 🏃‍♂️")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Warning
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Warning ⚠️")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.red)
                        Text("Bracing should only be done under medical supervision. Always consult a specialist for the best treatment plan. 🚨")
                            .foregroundColor(.red)
                            .font(.body)
                    }
                    .padding(.horizontal)
                }
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

#Preview {
    ScoliosisBraceInfoView()
}
