//
//  CobbAngleMeasureView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/9.
//

import SwiftUI

public struct CobbAngleMeasureView: View {
    @State private var angle: Double? = nil
    @State private var answerAngle: Double = 48
    @State private var showPhotoZoomPage: Bool = false
    @State private var selectedImage: UIImage? = nil
    @State private var imageIndex: Int = 0
    
    private var images: [(imageName: String, answerAngle: Double)] = [("042721", 48.64), ("072221", 30.84), ("080822", 56.99), ("082824", 82.87), ("120924", 28.48)]
    
    let eps: Double = 7
    
    public var body: some View {
        VStack {
            NavigationLink(destination: CobbAngleInfoView()) {
                HStack {
                    Spacer()
                    
                    Text("How To Measure ?")
                    Image(systemName: "questionmark.circle")
                    
                }
                .padding(.horizontal)
            }
            
            Spacer()
            
            if angle == nil {
                //                TitleTypewriterView(
                //                    text: "Cobb Angle Measurement",
                //                    typingSpeed: 0.08,
                //                    typeFeedback: true
                //                )
                Text("Cobb Angle Measurement")
                    .font(.title)
                    .bold()
                
                Text("Next, there will be some X-ray images.\nPlease read the instructions and then try measuring them.")
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Button(action: {
                    showPhotoZoomPage = true
                }) {
                    Text(imageIndex == 0 ? "Let's Try!" : "Continue")
                        .bold()
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(height: 40.0)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                }
            } else {
                VStack {
                    VStack(alignment: .trailing) {
                        HStack {
                            Text("Answer is ")
                                .font(.title3)
                                .bold()
                                .foregroundColor(.secondary)
                                .frame(height: 20.0)
                            
                            Text("\(images[imageIndex].answerAngle, specifier: "%.2f")°")
                                .font(.body)
                                .bold()
                                .foregroundColor(.secondary)
                                .frame(height: 20.0)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                        }
                        
                        HStack {
                            Text("Your Answer is ")
                                .font(.title3)
                                .bold()
                                .foregroundColor(.secondary)
                                .frame(height: 20.0)
                            
                            Text("\(angle ?? 0, specifier: "%.2f")°")
                                .font(.body)
                                .bold()
                                .foregroundColor(.secondary)
                                .frame(height: 20.0)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                        }
                    }
                    
                    Image(images[imageIndex].imageName + "Answer")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 420)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                }
                
                if abs((angle ?? 0) - images[imageIndex].answerAngle) <= eps {
                    if imageIndex + 1 < images.count {
                        VStack {
                            Text("Correct!")
                                .font(.title3)
                                .bold()
                                .foregroundColor(.secondary)
                        }
                        .bold()
                        
                        Text("The error within \(Int(eps)) degrees is acceptable.")
                            .foregroundStyle(.secondary)
                            .font(.caption)
                            .padding(.bottom)
                        
                        Button(action: {
                            imageIndex = (imageIndex + 1) % images.count
                            selectedImage = UIImage(named: images[imageIndex].imageName)
                            showPhotoZoomPage = true
                            angle = nil
                        }) {
                            Text("Next Question")
                                .bold()
                                .font(.title2)
                                .foregroundColor(.secondary)
                                .frame(height: 40.0)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                        }
                    }
                    else {
                        VStack {
                            Text("All Correct!")
                                .font(.title3)
                                .bold()
                                .foregroundColor(.secondary)
                        }
                        .bold()
                        
                        Text("The error within \(Int(eps)) degrees is acceptable.")
                            .foregroundStyle(.secondary)
                            .font(.caption)
                            .padding(.bottom)
                        
                        Button(action: {
                            imageIndex = (imageIndex + 1) % images.count
                            selectedImage = UIImage(named: images[imageIndex].imageName)
                            showPhotoZoomPage = true
                            angle = nil
                        }) {
                            Text("Play Again")
                                .bold()
                                .font(.title2)
                                .foregroundColor(.secondary)
                                .frame(height: 40.0)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                        }
                    }
                }
                else {
                    VStack {
                        Text("Wrong!")
                            .font(.title3)
                            .bold()
                            .foregroundColor(.secondary)
                    }
                    .bold()
                    
                    Text("The error within \(Int(eps)) degrees is acceptable.")
                        .foregroundStyle(.secondary)
                        .font(.caption)
                        .padding(.bottom)
                    
                    Button(action: {
                        showPhotoZoomPage = true
                        angle = nil
                    }) {
                        Text("Try Again")
                            .bold()
                            .font(.title2)
                            .foregroundColor(.secondary)
                            .frame(height: 40.0)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(.ultraThinMaterial)
                            .clipShape(Capsule())
                    }
                }
            }
            
            Spacer()
        }
        .onAppear {
            selectedImage = UIImage(named: images[imageIndex].imageName)
        }
        .fullScreenCover(isPresented: $showPhotoZoomPage) {
            ZoomingDraggingRotatingImageView(angle: $angle, showPage: $showPhotoZoomPage, selectedImage: $selectedImage)
        }
    }
}

#Preview {
    CobbAngleMeasureView()
}
