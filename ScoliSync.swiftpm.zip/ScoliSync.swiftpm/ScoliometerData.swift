//
//  ScoliometerData.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/1.
//

import SwiftUI
import SwiftData

@Model
class ScoliometerData: Identifiable {
    @Attribute(.unique) var id: UUID
    var time: Date
    var angle: Double
    
    init(time: Date, angle: Double) {
        self.id = UUID()
        self.time = time
        self.angle = angle
    }
}
