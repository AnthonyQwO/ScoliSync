//
//  FloatingButton.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/1.
//

import SwiftUI

struct FloatingButton: View {
    @State private var isExpanded = false
    private let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    
    let items: [(icon: String, color: Color, destination: AnyView)] = [
        ("angle", .blue, AnyView(RadiologyDataSaveView())),
        ("level", .green, AnyView(ScoliometerMeasureView()))
    ]
    
    // MARK: - Floating Button
    var body: some View {
        VStack {
            Spacer()
            // 子按鈕
            if isExpanded {
                ForEach(items.indices, id: \.self) { index in
                    NavigationLink(destination: items[index].destination) {
                        Image(systemName: items[index].icon)
                            .foregroundColor(.white)
                            .frame(width: 55, height: 55)
                            .background(.ultraThinMaterial)
                            .background(items[index].color)
                            .clipShape(Circle())
                            .shadow(radius: 5)
                    }
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .animation(.spring(response: 0.4, dampingFraction: 1, blendDuration: 0).delay(Double(index) * 0.1))
                }
            }
            
            // 主按鈕
            Button(action: {
                withAnimation {
                    isExpanded.toggle()
                    impactFeedback.impactOccurred()
                }
            }) {
                Image(systemName: "plus")
                    .foregroundColor(.white)
                    .font(.system(size: 24, weight: .bold))
                    .frame(width: 60, height: 60)
                    .background(.ultraThinMaterial)
                    .background(Color.accentColor)
                    .clipShape(Circle())
                    .shadow(radius: 5)
                    .rotationEffect(.degrees(isExpanded ? 45 : 0))
                    .animation(.spring(response: 0.4, dampingFraction: 1, blendDuration: 0))
            }
        }
        .padding(.bottom, 16)
        .padding(.trailing, 16)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
        .onAppear {
            // 準備震動裝置
            impactFeedback.prepare()
        }        
    }
}

#Preview {
    FloatingButton()
}
