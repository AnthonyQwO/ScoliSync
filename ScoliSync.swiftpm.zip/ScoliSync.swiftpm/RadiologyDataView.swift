//
//  RadiologyDataView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/3.
//

import SwiftUI
import SwiftData

struct RadiologyDataView: View {
    @Query private var radiologyDatasets: [RadiologyData]
    @Environment(\.modelContext) private var modelContext
    
    var body: some View {
        VStack {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(radiologyDatasets) { dataset in
                        NavigationLink(destination: RadiologyDataEditView(dataset: dataset)) {
                            RadiologyDatasetGridView(dataset: dataset)
                        }
                        .padding()
                        .contextMenu {
                            Button(role: .destructive) {
                                deleteData(dataset)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                    
                    NavigationLink(destination: RadiologyDataSaveView()) {
                        VStack {
                            Text("Add Spine X-Ray")
                                .foregroundColor(.secondary)
                                .bold()
                                .padding()
                            
                            Image(systemName: "plus.circle")
                                .foregroundColor(.secondary)
                                .font(.title)
                            
                        }
                        .frame(width: 250.0, height: 450.0)
                        .background(
                            RoundedRectangle(cornerRadius: 16) // 圓角矩形背景
                                .fill(.ultraThinMaterial) // 可以選擇背景顏色
                                // .shadow(color: .secondary, radius: 5) // 可選擇陰影效果
                        )
                        .padding()
                    }

                }
                .animation(.default, value: radiologyDatasets.count)
            }
        }
        // .navigationTitle("Spine X-Ray")
    }
    
    private func deleteData(_ dataset: RadiologyData) {
        modelContext.delete(dataset)
        try? modelContext.save()
    }
}

struct RadiologyDatasetGridView: View {
    let dataset: RadiologyData
    
    var body: some View {
        VStack {
            VStack {
                Text(dataset.time.formatted(.dateTime.year().month().day()))
                    .font(.body)
                    .bold()
                    .foregroundColor(.secondary)
                    .frame(height: 20.0)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
                
                if let image = dataset.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                
                Text(dataset.CobbAngle == nil ? "No Data" : "\(dataset.CobbAngle ?? 0, specifier: "%.2f")°")
                    .font(.body)
                    .bold()
                    .foregroundColor(.secondary)
                    .frame(height: 20.0)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
                
            }
            .padding()
        }
        .frame(width: 250.0, height: 450.0)
        .background(
            RoundedRectangle(cornerRadius: 16) // 圓角矩形背景
                .fill(.ultraThinMaterial) // 可以選擇背景顏色
                .shadow(color: Color.black.opacity(0.2), radius: 5) // 可選擇陰影效果
        )

    }
}


#Preview {
    RadiologyDataView()
}
