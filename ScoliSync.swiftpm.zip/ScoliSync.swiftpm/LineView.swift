//
//  LineView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/1/20.
//

import SwiftUI

struct Line: Identifiable {
    var id = UUID()
    var start: CGPoint
    var end: CGPoint
}

struct LineView: View {
    var line: Line
    
    var body: some View {
        Path { path in
            path.move(to: line.start)
            path.addLine(to: line.end)
        }
        .stroke(Color.green, lineWidth: 2)
    }
}
