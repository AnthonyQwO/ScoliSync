//
//  RadiologyHistoryView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/9.
//

import SwiftUI
import SwiftData
import Charts

struct RadiologyBarChartView: View {
    @Query private var radiologyData: [RadiologyData]
    
    // 依照時間排序資料
    private var sortedData: [RadiologyData] {
        radiologyData.sorted { $0.time < $1.time }
    }
    
    /// 計算 X 軸範圍：
    /// - 若有資料：以資料中最小與最大時間，左右各延伸 3 month
    /// - 若無資料：以現在為中心，左右各延伸  3 month
    private var extendedXDomain: ClosedRange<Date> {
        let calendar = Calendar.current
        if sortedData.isEmpty {
            let now = Date()
            let start = calendar.date(byAdding: .month, value: -0, to: now) ?? now
            let end   = calendar.date(byAdding: .month, value: 0, to: now) ?? now
            return start...end
        } else {
            let first = sortedData.first!.time
            let last  = sortedData.last!.time
            let start = calendar.date(byAdding: .month, value: -0, to: first) ?? first
            let end   = calendar.date(byAdding: .month, value: 0, to: last) ?? last
            return start...end
        }
    }
    
    // 用於儲存選取的資料點與手指位置（顯示 tooltip 用）
    @State private var selectedData: (data: RadiologyData, location: CGFloat)? = nil
    
    var body: some View {
        Chart {
            // ─────────────────────────────
            // 繪製左右邊界的格線
            // 若有資料則以資料的第一筆與最後一筆時間作為格線位置，
            // 若無資料則以 extendedXDomain 的端點作為格線位置。
            let gridStart = sortedData.first?.time ?? extendedXDomain.lowerBound
            let gridEnd   = sortedData.last?.time ?? extendedXDomain.upperBound
            
            RuleMark(x: .value("Start", gridStart))
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [5]))
                .foregroundStyle(Color.gray.opacity(0.5))
            RuleMark(x: .value("End", gridEnd))
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [5]))
                .foregroundStyle(Color.gray.opacity(0.5))
            
            // ─────────────────────────────
            // 繪製長條圖：若有資料且角度不為 nil
            ForEach(sortedData) { data in
                if let angle = data.CobbAngle {
                    BarMark(
                        x: .value("Time", data.time),
                        y: .value("Angle", angle)
                    )
                    .foregroundStyle(.blue)
                }
            }
        }
        // 使用預設或資料延伸後的 X 軸範圍
        .chartXScale(domain: extendedXDomain)
        // 自訂 X 軸標籤：以「月 日 年」格式呈現
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 5)) { value in
                AxisGridLine()
                AxisTick()
                AxisValueLabel(format: Date.FormatStyle.dateTime.month().day().year())
            }
        }
        // ─────────────────────────────
        // 加入互動手勢與 tooltip（有資料時可用）
        .chartOverlay { proxy in
            GeometryReader { geo in
                Rectangle()
                    .fill(Color.clear)
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                let location = value.location
                                if let date: Date = proxy.value(atX: location.x) {
                                    if let nearest = sortedData.min(by: {
                                        abs($0.time.timeIntervalSince(date)) < abs($1.time.timeIntervalSince(date))
                                    }) {
                                        selectedData = (nearest, location.x)
                                    }
                                }
                            }
                            .onEnded { _ in
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    withAnimation {
                                        selectedData = nil
                                    }
                                }
                            }
                    )
            }
        }
        // 在圖表上疊加 tooltip，顯示詳細角度與時間資訊
        .overlay(alignment: .topLeading) {
            if let selected = selectedData {
                VStack(alignment: .leading, spacing: 4) {
                    if let angle = selected.data.CobbAngle {
                        Text("Angle: \(angle, specifier: "%.2f")°")
                    }
                    Text("\(selected.data.time, format: Date.FormatStyle.dateTime.month().day().year())")
                }
                .padding(8)
                .foregroundStyle(.secondary)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(.ultraThinMaterial)
                )
                .position(x: selected.location, y: 30)
                .transition(.opacity)
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16) // 圓角矩形背景
                .fill(.ultraThinMaterial) // 可以選擇背景顏色
                // .shadow(color: .secondary, radius: 5) // 可選擇陰影效果
        )
        // 當資料為空時，疊加顯示「暫無資料」提示
        .overlay {
            if sortedData.isEmpty {
                Text("No Data")
                    .foregroundColor(.secondary)
                    .padding()
            }
        }
        .frame(height: 180)
        .padding()
    }
}


struct RadiologyHistoryView: View {
    public var body: some View {
        VStack {
            HStack {
                Text("Spine X-Rays")
                Spacer()
            }
            .font(.title)
            .bold()
            .padding(.horizontal)
            
            ScrollView {
                VStack {
                    
                    RadiologyBarChartView()
                    
                    Divider()
                    
                    NavigationLink(destination: CobbAngleInfoView()) {
                        HStack {
                            Spacer()
                            
                            Text("How To Measure ?")
                            Image(systemName: "questionmark.circle")
                            
                        }
                        .padding(.horizontal)
                    }
                    
                    RadiologyDataView()
                    
                    Spacer()
                }
            }
        }
        .padding(.horizontal)
    }
}

#Preview {
    RadiologyHistoryView()
}
