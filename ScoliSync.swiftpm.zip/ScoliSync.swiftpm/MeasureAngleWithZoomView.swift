//
//  MeasureAngleWithZoomView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/1/27.
//

import SwiftUI

struct ZoomingDraggingRotatingImageView: View {
    @State private var scale: CGFloat = 1.0
    @State private var lastScale = 0.0
    @State private var offset = CGSize.zero
    @State private var lastOffset = CGSize.zero
    @State private var rotation: Angle = .degrees(0)
    @State private var lastRotation = Angle(degrees: 0)
    @State private var viewSize: CGSize = .zero
    @State private var imageSize: CGSize = CGSize(width: 250, height: 250) // 假設圖片初始大小
    @State private var zoomScale: CGFloat = 1.0
    @State private var showAnglePage: Bool = false
    @State private var AngleMeasureLock: Bool = false
    
    // angle measure
    @State private var lines: [Line] = []
    @State private var currentLine: Line?
    
    @Binding var angle: Double?
    @Binding var showPage: Bool
    @Binding var selectedImage: UIImage?
        
    // MARK: - Page
    var body: some View {
        VStack {
            ZStack {
                if selectedImage != nil {
                    Image(uiImage: selectedImage!)
                        .resizable()
                        .scaleEffect(scale)
                        .rotationEffect(rotation)
                        .offset(offset)
                        .scaledToFit()
                        .padding()
                }
                
                ForEach(lines) { line in
                    LineView(line: line)
                }
                
//                VStack {
//                    ForEach(lines) { line in
//                        Text("\(line.start), \(line.end)")
//                            .foregroundStyle(.white)
//                    }
//                }

                if let currentLine = currentLine {
                    LineView(line: currentLine)
                }
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            // MARK: - Gesture
            .gesture(!AngleMeasureLock ? gesture : nil)
            .gesture(DragGesture()
                .onChanged { value in
                    if AngleMeasureLock {
                        if currentLine == nil {
                            currentLine = Line(start: value.startLocation, end: value.location)
                        } else {
                            currentLine?.end = value.location
                        }
                    }
                }
                .onEnded { _ in
                    if AngleMeasureLock {
                        if let finishedLine = currentLine {
                            lines.append(finishedLine)
                            currentLine = nil
                            if lines.count == 2 {
                                angle = calculateAngle(lines[0], lines[1])
                            }
                        }
                    }
                }
            )
            .background(.background)
            .overlay {
                FloatingToolbarView(showPage: $showPage, angle: $angle, AngleMeasureLock: $AngleMeasureLock, lines: $lines)
            }
            .onChange(of: AngleMeasureLock) {
                if !AngleMeasureLock {
                    lines.removeAll()
                    angle = nil
                }
            }
            .animation(.default, value: AngleMeasureLock)
        }
    }
    
    
    // MARK: - Calculate Angle
    func calculateAngle(_ line1: Line, _ line2: Line) -> CGFloat {
        // 計算向量 A 和向量 B
        let vectorA = CGPoint(x: line1.end.x - line1.start.x, y: line1.end.y - line1.start.y)
        let vectorB = CGPoint(x: line2.end.x - line2.start.x, y: line2.end.y - line2.start.y)
        
        // 計算點積 A · B
        let dotProduct = vectorA.x * vectorB.x + vectorA.y * vectorB.y
        
        // 計算向量 A 和向量 B 的模長
        let magnitudeA = sqrt(vectorA.x * vectorA.x + vectorA.y * vectorA.y)
        let magnitudeB = sqrt(vectorB.x * vectorB.x + vectorB.y * vectorB.y)
        
        // 計算 cosθ
        let cosTheta = dotProduct / (magnitudeA * magnitudeB)
        
        // 防止數值誤差導致 cosθ 超出範圍 [-1, 1]
        let clampedCosTheta = max(min(cosTheta, 1.0), -1.0)
        
        // 計算角度（以弧度為單位）
        let angle = acos(clampedCosTheta)
        
        // 如果需要返回角度（以度數為單位），可以用以下代碼轉換：
        let angleInDegrees = angle * 180 / .pi
        
        return angleInDegrees
    }
    
    // MARK: - Gesture
    var gesture: some Gesture {
        ExclusiveGesture(
            TapGesture(count: 2)
                .onEnded {
                    withAnimation(.spring()) {
                        scale = 1.0
                        rotation = .degrees(0)
                        offset = .zero
                    }
                },
            SimultaneousGesture(
                scaleGesture,
                dragGesture
            )
        )
    }
}

struct FloatingToolbarView: View {
    @Binding var showPage: Bool
    @Binding var angle: Double?
    @Binding var AngleMeasureLock: Bool
    @Binding var lines: [Line]
    
    var body: some View {
        // MARK: - Tool Bar
        VStack {
            HStack {
                Button(action: {
                    showPage = false
                }) {
                    Image(systemName: "xmark")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(width: 20.0, height: 20.0)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
                
                Spacer()
                
                // 顯示角度
                if let angle = angle {
                    Text("\(angle, specifier: "%.2f")°")
                        .font(.body)
                        .bold()
                        .foregroundColor(.secondary)
                        .frame(height: 20.0)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                }
                
                Button(action: {
                    AngleMeasureLock.toggle()
                }) {
                    Image(systemName: AngleMeasureLock ? "arrow.up.and.down.and.arrow.left.and.right" : "angle")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(width: 20.0, height: 20.0)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
                
                Button(action: {
                    lines.removeAll()
                    angle = nil
                }) {
                    Image(systemName: "arrow.trianglehead.clockwise.rotate.90")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(width: 20.0, height: 20.0)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
                
                Button(action: {
                    showPage = false
                }) {
                    Text("Next")
                        .font(.body)
                        .bold()
                        .foregroundColor(.secondary)
                        .frame(height: 20.0)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                        .opacity(angle == nil ? 0.3 : 1)
                }
                .disabled(angle == nil)
            }
            .padding(.horizontal, 24)
            .padding(.top)  // 增加頂部邊距到 60
                                
            Spacer()  // 確保工具欄位於頂部
        }

    }
}

// MARK: - Scale
private extension ZoomingDraggingRotatingImageView {
    var scaleGesture: some Gesture {
        MagnificationGesture(minimumScaleDelta: 0)
            .onChanged { value in
                withAnimation(.interactiveSpring()) {
                    scale = handleScaleChange(value)
                }
            }
            .onEnded { _ in
                withAnimation(.spring()) {
                    // 回彈到最小值
                    if scale < 0.8 {
                        scale = 0.8
                    }
                }
                lastScale = scale
            }
    }
    
    private func handleScaleChange(_ zoom: CGFloat) -> CGFloat {
        let speedFactor: CGFloat = 1.5  // 控制縮小速度的加速因子
        return lastScale + (zoom - 1) * speedFactor  // 加快縮小速度
    }
}

// MARK: - Drag
private extension ZoomingDraggingRotatingImageView {
    var dragGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                withAnimation(.interactiveSpring()) {
                    offset = handleOffsetChange(value.translation)
                }
            }
            .onEnded { _ in
                withAnimation(.spring()) {
                    offset = handleBoundaryBounce(offset)
                }
                lastOffset = offset
            }
    }
    
    private func handleOffsetChange(_ translation: CGSize) -> CGSize {
        var newOffset = CGSize.zero
        newOffset.width = translation.width + lastOffset.width
        newOffset.height = translation.height + lastOffset.height
        return newOffset
    }
    
    private func handleBoundaryBounce(_ currentOffset: CGSize) -> CGSize {
        // 設定圖片邊緣可移動範圍的距離
        let margin: CGFloat = 50 // 固定邊界距離，可調整
        
        // 計算圖片邊緣距離範圍
        let maxOffsetX = (imageSize.width * scale - viewSize.width) / 2 + margin
        let maxOffsetY = (imageSize.height * scale - viewSize.height) / 2 + margin
        
        // 限制移動範圍在圖片邊緣內
        var bouncedOffset = currentOffset
        
        // 水平方向邊界檢查
        if currentOffset.width > maxOffsetX {
            bouncedOffset.width = maxOffsetX
        } else if currentOffset.width < -maxOffsetX {
            bouncedOffset.width = -maxOffsetX
        }
        
        // 垂直方向邊界檢查
        if currentOffset.height > maxOffsetY {
            bouncedOffset.height = maxOffsetY
        } else if currentOffset.height < -maxOffsetY {
            bouncedOffset.height = -maxOffsetY
        }
        
        return bouncedOffset
    }
    
}

// MARK: - Rotation
private extension ZoomingDraggingRotatingImageView {
    var rotationGesture: some Gesture {
        RotationGesture()
            .onChanged { value in
                withAnimation(.interactiveSpring()) {
                    rotation = handleRotationChange(value)
                }
            }
            .onEnded { _ in
                lastRotation = rotation
            }
    }
    
    private func handleRotationChange(_ angle: Angle) -> Angle {
        lastRotation + angle
    }
}

#Preview {
    RadiologyDataSaveView()
}
