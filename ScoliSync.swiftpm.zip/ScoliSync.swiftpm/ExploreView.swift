//
//  ExploreView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/5.
//

import SwiftUI

public struct ExploreView: View {
    let exploreSection: [(title: String, icon: String, imageName: String, color: Color, destination: AnyView)]
    
    public var body: some View {
        
        VStack {
            HStack {
                Text("Explore")
                Spacer()
            }
            .font(.title)
            .bold()
            .foregroundColor(.primary)
            .padding(.horizontal)
            
            ScrollView {
                VStack {
                    ForEach(exploreSection, id: \.title) { section in
                        NavigationLink(
                            destination: section.destination
                        ) {
                            let item = section
                            
                            ZStack {
                                // 背景層
                                item.color
                                
                                // 模糊效果層
                                Rectangle()
                                    .fill(.ultraThinMaterial)
                                
                                // 漸層層
                                LinearGradient(
                                    gradient: Gradient(colors: [.clear, item.color.opacity(0.8)]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                                
                                // 右側圖片
                                GeometryReader { geometry in
                                    Image(item.imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: geometry.size.width / 2)
                                        .clipped()
                                        .position(x: geometry.size.width * 0.75, y: geometry.size.height / 2)
                                }
                                
                                // 內容層
                                HStack {
                                    VStack(alignment: .leading, spacing: 30) {
                                        Image(systemName: item.icon)
                                            .foregroundColor(.white)
                                            .font(.title)
                                            .bold()
                                        
                                        Text(item.title)
                                            .foregroundColor(.white)
                                            .font(.title3)
                                    }
                                    .padding()
                                    Spacer()
                                }
                            }
                            .frame(width: 350, height: 180)
                            .clipShape(RoundedRectangle(cornerRadius: 25))
                            .shadow(color: .secondary, radius: 5)
                            .padding(.horizontal)
                        }
                        .padding()
                    }
                }
            }
        }
        .padding()
    }
}
