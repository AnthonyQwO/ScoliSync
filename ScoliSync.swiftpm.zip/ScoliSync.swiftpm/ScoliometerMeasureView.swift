//
//  ScoliometerMeasureView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/1/21.
//

import SwiftUI
import CoreMotion

class MotionManager: ObservableObject {
    private var motionManager = CMMotionManager()
    @Published var pitch: Double = 0.0
    @Published var roll: Double = 0.0
    @Published var yaw: Double = 0.0
    
    init() {
        startDeviceMotionUpdates()
    }
    
    func startDeviceMotionUpdates() {
        if motionManager.isDeviceMotionAvailable {
            motionManager.deviceMotionUpdateInterval = 0.1
            motionManager.startDeviceMotionUpdates(to: .main) { (motion, error) in
                if let motion = motion {
                    // 將角度轉換為度數並更新
                    self.pitch = motion.attitude.pitch * 180 / .pi
                    self.roll = motion.attitude.roll * 180 / .pi
                    self.yaw = motion.attitude.yaw * 180 / .pi
                }
            }
        }
    }
    
    func stopDeviceMotionUpdates() {
        motionManager.stopDeviceMotionUpdates()
    }
}



struct ScoliometerMeasureView: View {
    @StateObject private var motionManager = MotionManager()
    // 添加震動管理器
    private let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    // 記錄上一次的角度，用於判斷是否需要震動
    @State private var lastAngle: Double = 0
    @State private var lockAngle: Double = 0
    @State private var angleLock: Bool = false
    @State private var selectedDate: Date = Date()
    @State private var showAlert: Bool = false
    @State private var direction: Double = 1
    
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack {
            HStack {
                DatePicker("Select Time", selection: $selectedDate, displayedComponents: .date)
                    .labelsHidden()
                Spacer() // 推到左側
            }
            .padding(.leading) // 增加左側間距，使其不緊貼邊緣
            .frame(maxWidth: .infinity, alignment: .leading) // 確保 DatePicker 貼齊左側
            
            Spacer()
            
            // Text("x: \(motionManager.pitch) y: \(motionManager.roll) z: \(motionManager.yaw)")
            
            Button("\(abs(angleLock ? lockAngle * direction : (motionManager.pitch * (motionManager.roll > 0 ? 1 : -1))), specifier: "%.2f")°") {
                angleLock.toggle()
                impactFeedback.impactOccurred()
                lockAngle = motionManager.pitch
                direction = motionManager.roll > 0 ? 1 : -1
            }
            .font(.title)
            .foregroundColor(.primary)
            .rotationEffect(.degrees((angleLock ? lockAngle * direction : (motionManager.pitch * (motionManager.roll > 0 ? 1 : -1)))))
            .padding(50) // 增加內邊距，讓圓形有足夠空間
            .background(Circle().stroke(lineWidth: 4).foregroundColor(.secondary).opacity(angleLock ? 1 : 0.3)) // 外框圓形
            .animation(.easeInOut, value: angleLock) // 淡入動畫
            
            if angleLock {
                Button("Save") {
                    var temp = ScoliometerData(time: selectedDate, angle: lockAngle * direction)
                    
                    context.insert(temp)
                    do {
                        try context.save()
                    } catch {
                        print("Failed to save context: \(error)")
                    }
                    
                    showAlert = true
                    dismiss()
                }
                .foregroundStyle(.secondary)
                .font(.title)
                // .bold()
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(.secondary, lineWidth: 3)
                )
                .opacity(angleLock ? 1 : 0)
                .animation(.easeInOut, value: angleLock) // 淡入動畫
                .padding()
            }
            
            Spacer()
            
            // .contentTransition(.numericText())
        }
        .onChange(of: motionManager.pitch) { newValue in
            // 當角度變化超過2度時觸發震動
            if !angleLock && abs(newValue - lastAngle) >= 2 {
                impactFeedback.impactOccurred()
                lastAngle = newValue
            }
        }
        .onAppear {
            motionManager.startDeviceMotionUpdates()
            // 準備震動裝置
            impactFeedback.prepare()
        }
        .onDisappear {
            motionManager.stopDeviceMotionUpdates()
        }
        .alert("Successfully saved!", isPresented: $showAlert) {}
        .navigationTitle("Scoliometer")
    }
}

// 自定義弧形形狀
struct Arc: Shape {
    let startAngle: Angle
    let endAngle: Angle
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.maxY)
        let radius = rect.width / 2
        
        path.addArc(center: center,
                    radius: radius,
                    startAngle: startAngle,
                    endAngle: endAngle,
                    clockwise: false)
        
        return path
    }
}

// 刻度線形狀
struct TickMark: Shape {
    let degree: Double
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.maxY)
        let radius = rect.width / 2
        
        let angle = Angle(degrees: degree)
        let outerPoint = CGPoint(
            x: center.x + radius * CGFloat(cos(angle.radians)),
            y: center.y + radius * CGFloat(sin(angle.radians))
        )
        let innerPoint = CGPoint(
            x: center.x + (radius - 10) * CGFloat(cos(angle.radians)),
            y: center.y + (radius - 10) * CGFloat(sin(angle.radians))
        )
        
        path.move(to: outerPoint)
        path.addLine(to: innerPoint)
        
        return path
    }
}

#Preview {
    ScoliometerMeasureView()
}
