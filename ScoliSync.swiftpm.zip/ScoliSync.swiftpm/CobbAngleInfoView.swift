//
//  CobbAngleInfoView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/4.
//

import SwiftUI

struct CobbAngleInfoView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // 標題區塊
            TitleTypewriterView(
                text: "Cobb Angle 📐",
                typingSpeed: 0.08,
                typeFeedback: false
            )
            .font(.title)
            .bold()
            
            // MARK: - 內容區塊 (使用 ScrollView 可捲動)
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // 介紹文字
                    Text("The **Cobb angle** is a key measurement used to assess the severity of scoliosis, a spinal condition characterized by abnormal curvature. It is determined by measuring the angle between the lines drawn along the most tilted vertebrae at the top and bottom of the curve. 🔍")
                        .padding(.horizontal)
                    
                    Divider()
                    
                    // 測量步驟標題
                    HStack {
                        Text("How to Measure 📏")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    Image("CobbExample")
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 400)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    // 測量步驟說明
                    VStack(alignment: .leading, spacing: 10) {
                        Text("1. Identify the most tilted vertebrae (Top and Bottom vertebrae). 🦴")
                        Text("2. Draw horizontal lines along the upper and lower edges of these vertebrae. ✏️")
                        Text("3. Measure the angle formed by the intersection of the perpendicular lines to the horizontal lines. 🔺")
                        Text("Using this tool will automatically calculate the angle, so you can skip this step. \n\nPlease note that this tool uses vector calculations, so make sure to draw the lines in the same direction.")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Cobb Angle 解讀
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text("Cobb Angle Interpretation ⚖️")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(.primary)
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        VStack(alignment: .leading, spacing: 10) {
                            Text("• **Less than 10°**\nNormal range, no treatment needed. ✅")
                            Text("• **10° - 25°**\nMild scoliosis, observation and regular check-ups. 👀")
                            Text("• **25° - 40°**\nModerate scoliosis, brace treatment may be needed. 🏥")
                            Text("• **Greater than 40° - 50°**\nSevere scoliosis, possible surgical intervention. ⚠️")
                        }
                        .padding(.horizontal)
                    }
                    
                    Divider()
                    
                    // 警告訊息
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Warning ⚠️")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.red)
                        Text("Always consult with a medical professional for an accurate diagnosis and treatment plan. Self-diagnosis or inappropriate treatment can worsen the condition. 🚨")
                            .foregroundColor(.red)
                            .font(.body)
                    }
                    .padding(.horizontal)
                }
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal)
    }
}


#Preview {
    CobbAngleInfoView()
}

