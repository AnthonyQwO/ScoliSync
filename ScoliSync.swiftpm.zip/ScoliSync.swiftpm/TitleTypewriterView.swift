//
//  TitleTypewriterView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/4.
//

import SwiftUI

struct TitleTypewriterView: View {
    let text: String
    let typingSpeed: Double // Character display interval (seconds)
    let typeFeedback: Bool
    
    @State private var displayedText = ""
    @State private var currentIndex = 0
    @State private var showCursor = true // Cursor blink state
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    
    var body: some View {
        HStack(spacing: 0) {
            Text(displayedText)
            Text("|")
                .opacity(showCursor ? 1 : 0)
                .animation(.easeInOut(duration: 0.6).repeatForever(), value: showCursor)
        }
        .onAppear {
            startTyping()
            startCursorAnimation()
        }
    }
    
    
    private func startTyping() {
        guard currentIndex < text.count else { return }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + typingSpeed) {
            let index = text.index(text.startIndex, offsetBy: currentIndex)
            displayedText += String(text[index])
            currentIndex += 1
            
            if typeFeedback {
                impactFeedback.impactOccurred()
            }
            
            startTyping()
        }
    }
    
    private func startCursorAnimation() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            withAnimation {
                showCursor.toggle()
                startCursorAnimation()
            }
        }
    }
}
