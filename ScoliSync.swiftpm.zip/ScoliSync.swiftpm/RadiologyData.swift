//
//  RadiologyData.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/2.
//

import SwiftUI
import SwiftData

@Model
class RadiologyData: Identifiable {
    @Attribute(.unique) var id: UUID
    var time: Date
    var CobbAngle: Double?
    var imageData: Data? // 用 Data 存圖片
    
    var image: UIImage? {
        get {
            guard let imageData else { return nil }
            return UIImage(data: imageData)
        }
        set {
            imageData = newValue?.jpegData(compressionQuality: 0.8) // 轉換為 Data
        }
    }
    
    init(time: Date, angle: Double?, image: UIImage?) {
        self.id = UUID()
        self.time = time
        self.CobbAngle = angle
        self.image = image // 透過 setter 自動存成 Data
    }
}
