//
//  ScoliosisInfoView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/2/5.
//

import SwiftUI

struct ScoliosisInfoView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Title Section
            TitleTypewriterView(
                text: "Scoliosis",
                typingSpeed: 0.08,
                typeFeedback: false
            )
            .font(.title)
            .bold()
            .padding(.horizontal)
            
            // Scrollable Content
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Introduction
                    VStack {
                        Text("**Scoliosis** is a medical condition where the spine curves sideways, forming an 'S' or 'C' shape.\n\n It is most commonly diagnosed in children and adolescents, but adults can also be affected. 🏥\n\nThe incidence rate is about 3%, and it typically occurs in adolescents between the ages of 10 and 20. \n\nThis condition worsens rapidly during the growth phase, and if it progresses to severe scoliosis, surgical treatment may be required. ⚠️📊\n")
                            
                        
                        // Image Section
                        HStack {
                            Spacer()
                            Image("080822")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: 200)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                            Spacer()
                        }
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Symptoms
                    HStack {
                        Text("Symptoms of Scoliosis 🩻")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("• Uneven shoulders or waistline. 🤷")
                        Text("• One shoulder blade appearing more prominent. 🔍")
                        Text("• The body leaning to one side. ⚖️")
                        Text("• Back pain or discomfort (in some cases). 💢")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Causes
                    HStack {
                        Text("Causes of Scoliosis 🧬")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("• **Idiopathic**: The most common type with no clear cause. ❓")
                        Text("• **Congenital**: Caused by abnormal spinal development before birth. 👶")
                        Text("• **Neuromuscular**: Linked to conditions like cerebral palsy or muscular dystrophy. 🧠")
                        Text("• **Degenerative**: Occurs in adults due to aging and wear on the spine. ⏳")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Treatment Options
                    HStack {
                        Text("Treatment Options 💊")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("• **Observation**: Mild cases may only require regular monitoring. 👀")
                        Text("• **Bracing**: Helps prevent curve progression in growing children. 🦺")
                        Text("• **Physical Therapy**: Exercises to improve posture and strength. 🏋️")
                        Text("• **Surgery**: Severe cases may require spinal fusion surgery. ⚕️")
                    }
                    .padding(.horizontal)
                    
                    Divider()
                    
                    // Warning
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Warning ⚠️")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.red)
                        Text("If you suspect scoliosis, consult a medical professional for an accurate diagnosis and treatment plan. Early intervention is key to managing the condition effectively. 🚨")
                            .foregroundColor(.red)
                            .font(.body)
                    }
                    .padding(.horizontal)
                }
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

#Preview {
    ScoliosisInfoView()
}
