//
//  TestView.swift
//  ScoliSync
//
//  Created by Tang Anthony on 2025/1/21.
//

import SwiftUI

#Preview {
    RadiologyBarChartView()
}

